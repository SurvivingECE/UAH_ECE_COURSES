
PowerPC
=========

naken_asm supports basic PowerPC instructions along with
Altivec and FPU instructions.

Support for 64 bit and some other instructions are not supported
yet.  Coming soon!


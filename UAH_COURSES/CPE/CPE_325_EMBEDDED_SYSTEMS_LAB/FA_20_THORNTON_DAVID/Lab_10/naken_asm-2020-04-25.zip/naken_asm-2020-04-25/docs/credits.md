Credits
=======

* Michael Kohn (http://www.mikekohn.net/)
  * Core assembler + assemblers, disassemblers, and simulators not mentioned below.
* Joe Davisson (https://github.com/Mortis69)
  * 6502 assembler, disassembler, simulator.
  * 65C816 assembler, disassembler.
* Lars Brinkhoff (https://github.com/larsbrinkhoff)
  * PDP-8 assembler, disasssembler.
* Zoltan Csahok (https://github.com/zcsahok)
* D.L. Karmann
  * STM8 simulator
* Malik Enes Safak
  * 1802 simulator


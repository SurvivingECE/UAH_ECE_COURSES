
int add_numbers_c(int a, int b)
{
  return a+b;
}

int counter(int a, int b)
{
  return a+1;
}


